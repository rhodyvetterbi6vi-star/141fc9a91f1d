# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(sonarcloud src/sonarcloud.cpp)
set_property(TARGET sonarcloud PROPERTY CXX_STANDARD 11)
target_link_libraries(sonarcloud lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(cross-mingw64 src/cross-mingw64.cpp)
set_property(TARGET cross-mingw64 PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-mingw64 lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(leap-second-tests src/leap-second-tests.cpp)
set_property(TARGET leap-second-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(leap-second-tests lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(clang-format-check src/clang-format-check.cpp)
set_property(TARGET clang-format-check PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format-check lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(function-coverage src/function-coverage.cpp)
set_property(TARGET function-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(function-coverage lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(pvs-studio src/pvs-studio.cpp)
set_property(TARGET pvs-studio PROPERTY CXX_STANDARD 11)
target_link_libraries(pvs-studio lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

