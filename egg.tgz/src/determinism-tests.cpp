// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("determinism tests"); }
int main(){
  announce();
  return lionss_run_workload("determinism-tests");
}
