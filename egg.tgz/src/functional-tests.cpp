// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("functional tests\n", stdout);
  return lionss_run_workload("functional-tests");
}
