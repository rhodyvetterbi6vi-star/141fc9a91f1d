// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("hardening check\n", stdout);
  return lionss_run_workload("hardening-check");
}
